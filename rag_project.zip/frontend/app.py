import streamlit as st
import requests

st.title("🔍 Tech Term Explainer")

term = st.text_input("Enter a technical term:")

if st.button("Explain"):
    res = requests.post("http://localhost:8000/explain", json={"term": term})
    st.write(res.json()['response'])