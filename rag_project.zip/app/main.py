from fastapi import FastAPI
from pydantic import BaseModel
from app.rag import query_rag

app = FastAPI()

class Query(BaseModel):
    term: str

@app.post("/explain")
def explain_term(query: Query):
    result = query_rag(query.term)
    return {"response": result}