from app.embedder import model, embed_texts
from app.vector_store import VectorStore
from app.data_loader import load_data
import openai

openai.api_key = "YOUR_OPENAI_API_KEY"

data_df = load_data()
store = VectorStore(dim=384)

descriptions = data_df['explanation'].tolist()
metadata = data_df.to_dict(orient='records')
embeddings = embed_texts(descriptions)
store.add(embeddings, metadata)

def query_rag(user_input):
    input_emb = embed_texts([user_input])[0]
    top_matches = store.search(input_emb)

    context = "\n".join([
        f"{m['term']}: {m['explanation']} (Analogy: {m['analogy']}, Use-case: {m['use_case']})"
        for m in top_matches
    ])

    prompt = f'''
User asked: "{user_input}"

Similar terms:
{context}

Using this context, explain "{user_input}" in:
1. Plain English
2. A real-world analogy
3. A short use case
    '''

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']