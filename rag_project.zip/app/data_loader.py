import pandas as pd

def load_data(path="data/tech_terms.csv"):
    return pd.read_csv(path)